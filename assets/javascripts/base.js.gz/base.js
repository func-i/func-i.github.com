(function() {
  this.BASE_COLORS = {
    blue: "rgb(3,168,171)",
    yellow: "rgb(255,189,27)",
    green: "rgb(0,126,0)",
    darkGray: "rgb(45,45,45)"
  };

}).call(this);
