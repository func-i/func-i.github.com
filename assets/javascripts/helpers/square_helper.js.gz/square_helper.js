(function() {
  this.SquareHelper = {
    windowOrientation: void 0,
    findSquare: function($elem) {
      var square;
      return square = $elem.data('obj');
    }
  };

}).call(this);
